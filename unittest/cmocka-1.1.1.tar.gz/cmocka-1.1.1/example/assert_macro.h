const char* get_status_code_string(const unsigned int status_code);
unsigned int string_to_status_code(const char* const status_code_string);
